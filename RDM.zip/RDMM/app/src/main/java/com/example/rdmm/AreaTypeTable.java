package com.example.rdmm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AreaTypeTable extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area_type_table);
    }
}