package com.example.rdmm;

import android.telecom.ConnectionRequest;
import android.widget.ListView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class controledlist {


    Connection connection;
    String connectionResult = "";
    Boolean isSuucess = false;

    public List<Map<String, String>> getList()
    {
        List<Map<String,String>>data=null;
        data=new ArrayList<Map<String,String>>();

        try {
            connectionhelper connectionhelper=new connectionhelper();
            connection=connectionhelper.conclass() ;
            if (connection!=null)
            {
                String qu="select *from AccountControlTable";
                Statement statement=connection.createStatement();
                ResultSet resultSet=statement.executeQuery(qu);
                while (resultSet.next())
                {
                    Map<String,String>dtname=new HashMap<String, String>();
                    dtname.put("accountControlID",resultSet.getString("AccountControlID"));
                    dtname.put("accountHead_ID",resultSet.getString("AccountHead_ID"));
                    dtname.put("user_ID",resultSet.getString("User_ID"));
                    dtname.put("accountControlName",resultSet.getString("AccountControlName"));
                    dtname.put("code",resultSet.getString("Code"));
                    data.add(dtname);


                }
                connectionResult="Success";
                isSuucess=true;
                connection.close();

            }
else
            {
                connectionResult="Failed";

            }



        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return data;
    }
}
