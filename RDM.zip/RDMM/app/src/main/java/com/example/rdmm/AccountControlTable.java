package com.example.rdmm;

import androidx.appcompat.app.AppCompatActivity;

import android.app.LauncherActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.List;
import java.util.Map;

public class AccountControlTable extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_control_table);
    }


 SimpleAdapter ad;
    public void GetData(View v)
    {
        ListView lstv=(ListView) findViewById(R.id.listvw2);
        List<Map<String,String>> Mydatalist=null;
        controledlist mydata=new controledlist();
        Mydatalist=mydata.getList();
        String[]fromw={"accountControlID","accountHead_ID","user_ID","accountControlName","code"};
        int[]Tow={R.id.accountControlID,R.id.accountHead_ID,R.id.user_ID,R.id.accountControlName,R.id.code};
ad= new SimpleAdapter(AccountControlTable.this,Mydatalist,R.layout.controllistlayout,fromw,Tow);

lstv.setAdapter(ad);

    }
}