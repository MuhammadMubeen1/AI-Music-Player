package com.example.rdmm;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
public class RDM extends AppCompatActivity {
    ListView listview;
    String[] Rdm = {"AccountControl", "AccountHead", "AccountSubControl", "AreaType", "Bank", "ClaimDetail", "ClaimProduct", "Claim"
            , "CustomerInvoiceDetail", "CustomerInvoice", "CustomerPayment", "CustomerType", "FinancialYear", "GAInvoice", "GeneralAccounts",
            "OwnerInvoice", "OwnerPayment", "Owners", "Plots", "Stock", "SupplierInvoiceDetail", "SupplierInvoice", "SupplierPayment", "Supplier",
            "Table", "TGAInvoiceTable", "TownGeneralAccountsTable", "TownStockTable", "TownSupplierInvoiceDetailTable", "TownSupplierInvoiceTable", "TownSupplierPaymentTable", "TownSupplierTable", "TownTable",
            "Transactions", "Users", "UserTypes", "VID", "Vouchers", "Weightage"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rdm);
        listview = findViewById(R.id.list);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(RDM.this, android.R.layout.simple_dropdown_item_1line, Rdm);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Toast.makeText(RDM.this, "Clicked " + Rdm[position], Toast.LENGTH_SHORT).show();

              if(position==0)
              {
                  Intent    intent=new Intent(view.getContext(),AccountControlTable.class);
                  startActivity(intent);
              }
                if(position==1)
                {
                    Intent    intent=new Intent(view.getContext(),AccountHeadTable.class);
                    startActivity(intent);
                }


               }}); }}
