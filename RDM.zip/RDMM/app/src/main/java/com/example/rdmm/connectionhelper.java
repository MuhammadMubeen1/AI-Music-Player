package com.example.rdmm;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;

public class connectionhelper {
    Connection con;
    String ip,port,db,un,pass;
    @SuppressLint("NewApi")
    public Connection conclass() {
        ip="192.168.43.116";
        port="5645";
        db="RDM";
        un="mubeen";
        pass="mubeen12";
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Connection connection = null;
        String ConnectionUrl = null;
        try {


            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            ConnectionUrl = "jdbc:jtds:sqlserver://" + ip + ":" + port + ";" + "databasename=" + db + ";user=" + un + ";password=" + pass + ";";

            connection = DriverManager.getConnection(ConnectionUrl);
        } catch (Exception exception) {
            Log.e("Error :", exception.getMessage());
        }
        return connection;
    }}
