package com.example.rdmm;

import androidx.appcompat.app.AppCompatActivity;

import android.app.LauncherActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void GetList(View v)
    {
        SimpleAdapter ad;
        ListView lstv=(ListView) findViewById(R.id.hello);
        List<Map<String,String>>Mydatalist=null;
        listview myData=new listview();
        Mydatalist=myData.getlist();
        String[]fromw={"userid","userIdX","userType_ID","fullName","email","username","password","userfather","userphone","useraddress","userdescription"};
        int[]Tow={R.id.userid,R.id.userIdX,R.id.userType_ID,R.id.fullName,R.id.email,R.id.username,R.id.password,R.id.userfather,R.id.userphone,R.id.useraddress,R.id.userdescription};
        ad=new SimpleAdapter(MainActivity.this,Mydatalist,R.layout.listlayouttemplate,fromw,Tow);
        lstv.setAdapter(ad);



    }
}