package com.example.rdmm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.List;
import java.util.Map;

public class AccountHeadTable extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_head_table);
    }



    SimpleAdapter ad;
    public void GetDataa(View v)
    {
        ListView lstv=(ListView) findViewById(R.id.listvw3);
        List<Map<String,String>> Mydatalist=null;
        accountheadtablelist mydata=new accountheadtablelist();
        Mydatalist=mydata.getList();
        String[]fromw={"accountHeadID","user_I","accountHeadName","code"};
        int[]Tow={R.id.accountHeadID,R.id.user_I,R.id.accountHeadName,R.id.code};
        ad= new SimpleAdapter(AccountHeadTable.this,Mydatalist,R.layout.accountheadtablelist,fromw,Tow);
        lstv.setAdapter(ad);

    }
}