package com.example.rdmm;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class accountheadtablelist {



    Connection connection;
    String connectionResult = "";
    Boolean isSuucess = false;

    public List<Map<String, String>> getList()
    {
        List<Map<String,String>>data=null;
        data=new ArrayList<Map<String,String>>();

        try {
            connectionhelper connectionhelper=new connectionhelper();
            connection=connectionhelper.conclass() ;
            if (connection!=null)
            {
                String qu="select *from AccountHeadTable";
                Statement statement=connection.createStatement();
                ResultSet resultSet=statement.executeQuery(qu);
                while (resultSet.next())
                {
                    Map<String,String>dtname=new HashMap<String, String>();
                    dtname.put("accountHeadID",resultSet.getString("AccountHeadID"));
                    dtname.put("user_I",resultSet.getString("User_ID"));
                    dtname.put("accountHeadName",resultSet.getString("AccountHeadName"));
                    dtname.put("code",resultSet.getString("Code"));
                    data.add(dtname);


                }
                connectionResult="Success";
                isSuucess=true;
                connection.close();

            }
            else
            {
                connectionResult="Failed";

            }



        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return data;
    }
}
