package com.example.rdmm;

import android.widget.ListView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class listview {


    Connection connect;
    String ConnectionResult="";
    Boolean issuceess=false;
    public List<Map<String,String>>getlist()
    {
        List<Map<String,String>>data=null;
        data=new ArrayList<Map<String,String>>();
        try {
            connectionhelper connectionhelper=new connectionhelper();
            connect=connectionhelper.conclass();
            if(connect!=null)
            {
                String qu=" select *from UsersTable";
                Statement statement=connect.createStatement();
                ResultSet resultSet=statement.executeQuery(qu);
                while (resultSet.next())
                { Map<String,String> dtname=new HashMap<String,String>();
                    dtname.put("userid",resultSet.getString("UserID"));
                    dtname.put("userIdX",resultSet.getString("UserIdX"));
                    dtname.put("userType_ID",resultSet.getString("UserType_ID"));
                    dtname.put("fullName",resultSet.getString("FullName"));
                    dtname.put("email",resultSet.getString("Email"));
                    dtname.put("username",resultSet.getString("UserName"));
                    dtname.put("password",resultSet.getString("Password"));
                    dtname.put("userfather",resultSet.getString("userFather"));
                    dtname.put("userphone",resultSet.getString("userPhone"));
                    dtname.put("useraddress",resultSet.getString("userAddress"));
                    dtname.put("userdescription",resultSet.getString("userDescription"));
                    data.add(dtname); }
                 ConnectionResult="Success";
                issuceess=true;
                connect.close(); } else
            {
                ConnectionResult="Failed";
            }
        } catch (SQLException throwables)
        {
            throwables.printStackTrace();
        }
        return data;
    }
}
